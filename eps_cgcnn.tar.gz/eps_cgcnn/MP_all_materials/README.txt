Results from cgcnn_dielectric prediction on entire MP database.
