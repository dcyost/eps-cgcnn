After installing the prerequisite python libraries (see https://github.com/txie-93/cgcnn for details), the dielectric prediction model can be used as follows:

python ../../cgcnn_dielectric/predict.py dielectric_model.pth.tar ../structures/

Where "../structures/" is the directory containg the CIF structure files, the "id_prop.csv" file with placeholder values, and the "atom_init.json" file.  Again, see https://github.com/txie-93/cgcnn for detailed instructions. Note that the output "test_results.csv" outputs the logs (base 10) of the ionic and electronic contributions, respectively.

Other files in this directory include results for the oxygen-containing material predictions, as well as various other pieces of information, such as elements in each material, space groups, etc. 

One can find more detailed information about each material by using the Materials Project database and querying by the id (e.x. "mp-1001594"). See https://materialsproject.org/ 

 
