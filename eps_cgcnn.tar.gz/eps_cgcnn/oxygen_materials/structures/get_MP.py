from pymatgen.io.vasp.sets import MPRelaxSet
from pymatgen.io.xcrysden import XSF
from pymatgen.ext.matproj import MPRester
from pymatgen.io.cif import CifWriter
from pymatgen import Structure
from pprint import pprint
import math

# load structure

# you will need your own code here
m = MPRester("mprestercodehere")

entries = m.query(criteria={'elements': {"$all": ['O']}},  properties=["material_id"])

dielectric_mp_ids = [e['material_id'] for e in entries]

file1 = open("id_prop.csv", "w")

#for i in (350,400):
for i in range(len(dielectric_mp_ids)):
        file1.write(str(dielectric_mp_ids[i]) + ",1.0,1.0" + "\n")
        struct = m.get_structure_by_material_id(dielectric_mp_ids[i]);
        cif_struct = CifWriter(struct);
        cif_struct.write_file(str(dielectric_mp_ids[i]) + ".cif");
file1.close()
