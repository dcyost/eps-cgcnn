"id_prop.csv" contains the MP ids of all of the oxygen-containing materials for which the dielectric CGCNN model was applied. 
